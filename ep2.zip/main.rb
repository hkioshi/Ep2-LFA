def extrair_endereco(endereco)
  ## Expressões regulares
  
  #Enconta logradouro e coloca na tela
  puts "logradouro = #{endereco.match(/(Av|Rua)\./)}"

  #Encontra rua e coloca na tela
  puts "rua = #{endereco.match(/(?<=\. )([a-zA-Záàâãéèêíïóôõöúçñ]| |\.)+/)}"

  #Encontra numero e coloca na tela
  puts "numero = #{endereco.match(/( \d+ )/)}"

  #Ve se existe complemento
  if endereco.match?(/([A-Za-z]+ [\d]+)(?=( -|,))/)  
    #se sim,acha e coloca na tela
    puts "complemento = #{endereco.match(/([A-Za-z]+ [\d]+)(?=( -|,))/)}"
  else
    #se não, coloca que nao tem
    puts "Complemeto = Nao ha"
  end

  #Ve se existe bairro
  if endereco.match?(/([a-zA-Záàâãéèêíïóôõöúçñ]| )+(?=, [A-Z])/)  
    #se sim,acha e coloca na tela
    puts "bairro = #{endereco.match(/([a-zA-Záàâãéèêíïóôõöúçñ]| )+(?=, [A-Z])/)}"
  else
    #se não, coloca que nao tem
    puts "bairro = Nao ha"
  end

  #Encontra cidade e coloca na tela
  puts "cidade = #{endereco.match(/([a-zA-Záàâãéèêíïóôõöúçñ]| )+(?= - [A-Z]{2},)/)}"
  
  #Encontra cidade e coloca na tela
  puts "sigla = #{endereco.match(/[A-Z]{2}(?=,)/)}"

  #Encontra cidade e coloca na tela
  puts "cep = #{endereco.match(/(\d{5})-(\d{2})/)}"

end

#Entrada de dado (texto + endereço)
endereco = " adasdasdsvidsvhisdhviuhdsvih Av. Eng. Eusébio Stevaux, 823 sala 1 - Santo Amaro, Rio de Janeiro - SP, 04696-00 dfsfsffadhfsgdhfkjkdjsh"

#chamada da função | Exibição de dados
extrair_endereco(endereco)